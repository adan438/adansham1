document.addEventListener("DOMContentLoaded", () => {
    const addBtn = document.getElementById("add-btn");
    const contactList = document.getElementById("contact-list");
    const popup = document.getElementById("popup");
    const popupContent = document.getElementById("popup-content");
    const closePopupBtn = document.getElementById("close-popup");
    const searchInput = document.getElementById("search");

    const contacts = [
        { name: 'Dorothy Gale', phone: '1234567890', email: 'DGale@example.com', address: '123 Elm Street', notes: 'her house got carried away' },
        { name: 'Scarecrow', phone: '9876543210', email: 'straw@example.com', address: '456 Oak Avenue', notes: 'Met at the cornmaze' },
        { name: 'The Tinman', phone: '5551234567', email: 'Woodman@example.com', address: '789 Pine Road', notes: '' },
        { name: 'The Cowardly Lion', phone: '3334445555', email: 'king@example.com', address: '', notes: 'Lives in the forest' }
    ];

    function renderContacts(filteredContacts = contacts) {
        contactList.innerHTML = '';
        if (filteredContacts.length === 0) {
            contactList.innerHTML = '<p>No contacts available</p>';
        } else {
            filteredContacts.forEach((contact, index) => {
                const li = document.createElement('li');
                li.className = 'contact';
                li.innerHTML = `
                    <h2>${contact.name}</h2>
                    <p class="phone">${contact.phone}</p>
                    <p class="email">${contact.email}</p>
                    <button class="edit-btn" data-index="${index}">Edit</button>
                    <button class="delete-btn" data-index="${index}">Delete</button>
                `;
                contactList.appendChild(li);
            });
        }
    }

    function showPopup(content) {
        popupContent.innerHTML = content;
        popup.style.display = 'flex';
    }

    function hidePopup() {
        popup.style.display = 'none';
    }

    function validatePhoneNumber(phone) {
        const phonePattern = /^\d{10}$/; // Regex pattern for exactly 10 digits
        return phonePattern.test(phone);
    }

    function isDuplicateName(name, excludeIndex = -1) {
        return contacts.some((contact, index) => contact.name.toLowerCase() === name.toLowerCase() && index !== excludeIndex);
    }

    function showErrorMessage(message) {
        const errorMsg = document.createElement('p');
        errorMsg.className = 'error';
        errorMsg.style.color = 'red';
        errorMsg.textContent = message;
        return errorMsg;
    }

    addBtn.addEventListener("click", () => {
        showPopup(`
            <h2>Add New Contact</h2>
            <form id="contact-form">
                <label>Name: <input type="text" name="name" required></label><br>
                <label>Phone: <input type="text" name="phone" required></label><br>
                <label>Email: <input type="email" name="email"></label><br>
                <label>Address: <input type="text" name="address"></label><br>
                <label>Notes: <textarea name="notes"></textarea></label><br>
                <button type="submit">Save</button>
            </form>
        `);

        const contactForm = document.getElementById("contact-form");
        contactForm.addEventListener("submit", (e) => {
            e.preventDefault();

            const formData = new FormData(contactForm);
            const newContact = {};
            formData.forEach((value, key) => newContact[key] = value);

            if (!validatePhoneNumber(newContact.phone)) {
                const errorMsg = showErrorMessage("Phone number must be exactly 10 digits.");
                contactForm.appendChild(errorMsg);
                return;
            }

            if (isDuplicateName(newContact.name)) {
                const errorMsg = showErrorMessage("A contact with this name already exists.");
                contactForm.appendChild(errorMsg);
                return;
            }

            contacts.push(newContact);
            renderContacts();
            hidePopup();
        });
    });

    contactList.addEventListener("click", (e) => {
        if (e.target.classList.contains("edit-btn")) {
            const index = e.target.dataset.index;
            const contact = contacts[index];
            showPopup(`
                <h2>Edit Contact</h2>
                <form id="edit-contact-form">
                    <label>Name: <input type="text" name="name" value="${contact.name}" required></label><br>
                    <label>Phone: <input type="text" name="phone" value="${contact.phone}" required></label><br>
                    <label>Email: <input type="email" name="email" value="${contact.email}"></label><br>
                    <label>Address: <input type="text" name="address" value="${contact.address}"></label><br>
                    <label>Notes: <textarea name="notes">${contact.notes}</textarea></label><br>
                    <button type="submit">Update</button>
                </form>
            `);

            const editForm = document.getElementById("edit-contact-form");
            editForm.addEventListener("submit", (e) => {
                e.preventDefault();

                const formData = new FormData(editForm);
                const updatedContact = {};
                formData.forEach((value, key) => updatedContact[key] = value);

                if (!validatePhoneNumber(updatedContact.phone)) {
                    const errorMsg = showErrorMessage("Phone number must be exactly 10 digits.");
                    editForm.appendChild(errorMsg);
                    return;
                }

                if (isDuplicateName(updatedContact.name, index)) {
                    const errorMsg = showErrorMessage("A contact with this name already exists.");
                    editForm.appendChild(errorMsg);
                    return;
                }

                contacts[index] = updatedContact;
                renderContacts();
                hidePopup();
            });
        }

        if (e.target.classList.contains("delete-btn")) {
            const index = e.target.dataset.index;
            contacts.splice(index, 1);
            renderContacts();
        }
    });

    searchInput.addEventListener("input", () => {
        const query = searchInput.value.toLowerCase();
        const filteredContacts = contacts.filter(contact =>
            contact.name.toLowerCase().includes(query) ||
            contact.phone.includes(query) ||
            contact.email.toLowerCase().includes(query)
        );
        renderContacts(filteredContacts);
    });

    closePopupBtn.addEventListener("click", hidePopup);

    renderContacts();
});
